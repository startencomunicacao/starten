<table class="table table-stages">
   <thead>
      <tr>
         <th><?php echo _l('name'); ?></th>
         <th><?php echo _l('weight'); ?></th>
         <th><?php echo _l('category'); ?></th>
        <th><?php echo _l('published'); ?></th>
      </tr>
   </thead>
</table>